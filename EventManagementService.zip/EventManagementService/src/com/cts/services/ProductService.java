package com.cts.services;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.cts.entities.Message;

@Path("/ProductService")
public class ProductService {
	@POST
	@Path("/AddProduct")
	public Response AddProduct(@FormParam("productId")int Id,@FormParam("productName")String Name) 
	{
		Message message=new Message();
		if((Id>0)&&Name!=null)
		{
			System.out.println("Product Id"+Id);
			message.setStatus("Received Data"+Id+""+Name);
		}
		return Response.status(200).header("Acess-control-Allow-Orgin", "*")
				.header("Access-Control-Allow-Headers","orgin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credentials", true)
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age","1209600" )
				.entity(message)
				.build();
		
	}
}
